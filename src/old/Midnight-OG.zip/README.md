<h1 align="center">Midnight UI</h1>
<p align="center">A clean, dark, and modern user interface for DiscordApp.</p>

![](https://i.imgur.com/CLQoAtb.png)

---
